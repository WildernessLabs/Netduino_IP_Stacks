//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "Netduino_IP_Interop.h"
#include "Netduino_IP_Interop_Netduino_IP_Interop_Wireless.h"

using namespace Netduino::IP::Interop;

void Wireless::UpdateConfiguration( UNSUPPORTED_TYPE param0, INT8 param1, HRESULT &hr )
{
}

void Wireless::SaveAllConfigurations( HRESULT &hr )
{
}


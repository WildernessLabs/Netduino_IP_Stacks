//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "Netduino_IP_Interop.h"
#include "Netduino_IP_Interop_Netduino_IP_Interop_NetworkInterface.h"

using namespace Netduino::IP::Interop;

void NetworkInterface::InitializeNetworkInterfaceSettings( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
}

void NetworkInterface::UpdateConfiguration( CLR_RT_HeapBlock* pMngObj, INT32 param0, HRESULT &hr )
{
}

INT32 NetworkInterface::GetNetworkInterfaceCount( HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

UNSUPPORTED_TYPE NetworkInterface::GetNetworkInterface( UINT32 param0, HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

UINT32 NetworkInterface::IPAddressFromString( LPCSTR param0, HRESULT &hr )
{
    UINT32 retVal = 0; 
    return retVal;
}


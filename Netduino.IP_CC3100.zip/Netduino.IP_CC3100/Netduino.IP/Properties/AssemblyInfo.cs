using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Netduino.IP")]
[assembly: AssemblyDescription("Netduino IP Stack")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Wilderness Labs")]
[assembly: AssemblyProduct("Netduino.IP")]
[assembly: AssemblyCopyright("Copyright © 2018 Wilderness Labs. All rights reserved.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1.0.3.0")]
[assembly: AssemblyFileVersion("1.0.3.0")]
